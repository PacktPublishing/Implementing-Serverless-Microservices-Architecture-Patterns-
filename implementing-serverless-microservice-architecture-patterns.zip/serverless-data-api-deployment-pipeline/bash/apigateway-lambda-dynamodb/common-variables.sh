#!/bin/sh
# Copyright (c) 2017-2018 Starwolf Ltd and Richard Freeman. All Rights Reserved.
# Licensed under the Apache License, Version 2.0

export profile="demo"
export region="eu-west-1"
export aws_account_id="000000000000"
export template="lambda-dynamo-data-api"
export bucket="testbucket121f"
export prefix="tmp/sam"