#!/bin/sh
# Copyright (c) 2017-2018 Starwolf Ltd and Richard Freeman. All Rights Reserved.
# Licensed under the Apache License, Version 2.0

export profile="demo"
export region="eu-west-1"
export aws_account_id="98131759939"
export template="lambda-step-functions"
export bucket="testbucket121f"
export prefix="tmp/sam"